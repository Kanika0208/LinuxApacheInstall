#!/bin/bash
sudo apt-get -y update

# install Apache2
sudo apt-get -y install apache2 

